# Ekzen Planfix V3.1.0 - Mobil Teknisyen Paneli

Bu sürümde masaüstü yönetici paneli korunarak mobilde ayrı teknisyen paneli eklendi.

- Telefonda masaüstü panel gizlenir.
- Bugün / Yarın / Yeni / Kalan / Biten servis filtreleri vardır.
- Mobil servis kartları büyük, tek elle kullanılabilir yapıdadır.
- Servis detayları alttan açılan mobil panel olarak gelir.
- Ara, WhatsApp, Yol Tarifi, Para Ekle, İşlem Yaz, Fişi Bitir hızlı işlemleri eklendi.
